<?php
/*
Plugin Name: New Product
Description: Ovaj plugin dodaje novi tip u wordpress-u.
Texdomain: newproduct
Version: 1.0
*/

add_action('init','kreiraj_custom_post_type');
add_action('init', 'kreiraj_custom_taxonomy');

function kreiraj_custom_post_type(){
	$name_id = 'product';
	$argumenti = array(
		'labels'=>array(
			'name'=>'Products',
			'singular_name'=>'Product',
			'new_item'=>'Dodaj Novi',
		),
		'public'=>true,
		'has_archive' => true,
		'rewrite'=>array('slug'=>'proizvod'),
		
	);
	register_post_type($name_id, $argumenti);
	
}

function kreiraj_custom_taxonomy(){
	$argumenti=array(
		'labels'=>array(
			'name'=>'Catalogues',
			'Singular_name'=>'Catalogue',
			'add_new_item'=>'Dodaj novi katalog',
		),
		'public'=> true,
		'hierarchial'=>true,

	)
	
	register_taxonomy('catalogue','product',$argumenti);
	
}